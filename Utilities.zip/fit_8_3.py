# -*- coding: utf-8 -*-
"""
Created on Fri May 11 13:30:59 2018

@author: Demon King
"""
import sys
import re
def is_symmetric(num_list):
    if (num_list[-1]%8)%2!=0 and (sum(num_list[:-1]))%2!=0:
        return(False)
    else:
        return(True)
        
def fit_8_3(number,ret_op=0,repeat=0):
    og_num = number
    length_list=[n for n in [0]*7]  
    if number <2:
        if number == 0:
            return(length_list)
        else:
            print("Length's less than 2' are not allowed")
    
    if number<=8:
        length_list[number-2] = 1
    elif number <=20:
        if number%2!=0:  # Odd
            if number == 9:
                length_list[2],length_list[3]=1,1
            elif number == 11:
                length_list[3],length_list[4]=1,1
            elif number == 13:
                if repeat!=1:
                    length_list[3],length_list[6]=1,1
                else:
                    length_list[4],length_list[5]=1,1
            elif number == 15:
                length_list[5],length_list[6]=1,1
            elif number == 17:
                length_list[4],length_list[3]=2,1
            elif number == 19:
                length_list[4],length_list[5]=2,1
        else: # Even
            if number == 14:
                length_list[4],length_list[6]=1,1
            elif number == 18:
                length_list[3],length_list[6]=2,1
            elif number == 20:
                length_list[2],length_list[6]=1,2
            else:
                if repeat!=1:
                    length_list[number//2-2] = 2
                else:
                    length_list[-3] = number//6
                    if number==10:
                        length_list[2],length_list[4]=1,1    
    else:
        #if number%8<16:
        if number%8<=2:
            length_list[-1] = number//8-1
            number=number%8+8
        else:
            length_list[-1] = number//8
            number=number%8
        length_list_2 = fit_8_3(number,repeat=1)
        length_list = [x + y for x,y in zip(length_list,length_list_2)]
    
        if repeat != 1:
            if number%8!=0 and (length_list[-1]%2!=0 and sum(length_list[:-1])==1): # Odd multiples of 8 with only 1 remainder
                    number = og_num
                    if number%2==0:
                        add_5 = 0
                        number = number//2
                        length_list = fit_8_3(number,repeat=1)
                        length_list = [c*2 for c in length_list]
                    else:
                        if number%8!=5:
                            add_5 = 1
                            ll = fit_8_3(number-5,repeat=1) 
                            if is_symmetric(ll) is not True:
                                number = (number-5)//2
                                length_list = fit_8_3(number,repeat=1)
                                length_list = [c*2 for c in length_list]
                            else:
                                length_list = ll
                        else:
                            add_5=0
                            length_list=[0,0,0,0,0,0,number//8-1]
                            number=13
                            length_list_2 = fit_8_3(number,repeat=1)
                            length_list = [x + y for x,y in zip(length_list,length_list_2)]
                            
                    
                    if add_5 == 1:
                        length_list[3] += 1
#        else:
#            if (number%8)==5:# Odd 8 with repeat
#                length_list[-1] = length_list[-1]-1
                
                    
    if sum([x*y for x,y in zip(list(range(2,9)),length_list)]) != og_num:
        print("Sum_mismatch in number ", og_num)
            
    if ret_op == 0:
        return(length_list)
    else:
        len_dict = []
        dict_key = list(range(2,9))
        for i in range(len(dict_key)):
            if length_list[i]!=0:
                len_dict.append([str(dict_key[i])+"'",length_list[i]])
        return(len_dict)

target = 33




         
            
         