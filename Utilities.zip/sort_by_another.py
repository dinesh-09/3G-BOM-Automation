# -*- coding: utf-8 -*-
"""
Created on Wed May 23 08:01:26 2018

@author: Demon King
"""
import operator
def sort_by_another(target,source=None,rev=False,ret_type=0):
    if source is None:
        source = target

    if type(source[0])==int or len(source[0])==1: #source = 1D
        ind_list = [x for x,_ in sorted(enumerate(source),key=operator.itemgetter(1),reverse=rev)]    
        
    else: # target = source = nD
        ind_list = range(len(source[0]))
        ind_list = [list(i) for i in zip(*sorted([list(i) for i in zip(*source,ind_list)],\
                                             key=operator.itemgetter(0, 1),reverse=rev))][-1]
    
    if ret_type != 0:
        return(ind_list)

    else:
        if len(target[0])==1: 
            target = [target[ind] for ind in ind_list]
        else: 
            target = [[target[row][ind] for ind in ind_list] for row in range(len(target))]
        
        return(target)
