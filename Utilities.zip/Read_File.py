# -*- coding: utf-8 -*-
"""
Created on Thu May 17 07:46:39 2018

@author: dbhatia
"""

def Read_File(filename):
    dat=[[m] for m in open (filename,'r')]
    dat = [line[0].split('\n')[0] for line in dat]
    return(dat)
                   