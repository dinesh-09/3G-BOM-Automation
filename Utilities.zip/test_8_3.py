# -*- coding: utf-8 -*-
"""
Created on Thu Jul 19 13:03:43 2018

@author: Demon King
"""

import numpy as np

import matplotlib.pyplot as plt
ans = fit_8_3(target)
for a in range(2,9):
    if ans[a-2] !=0:
        print("Number of sections of length",a,"feet totalling to",target,"feet are",ans[a-2],)
start = 9
end=start+21
n_4 = []
n_6 = []
max_nos = 0
N_lengths =  [n for n in [0]*7]  
lengths = [2,3,4,5,6,7,8]
rect_labels = []
#fig1 = plt.figure(1,figsize=(12,10))
#ax1 = fig1.subplots()
#fig2 = plt.figure(2,figsize=(12,10))
#ax2 = fig2.subplots()
high_lengths = []
g = []
xticks = []

fig3 = plt.figure(3,figsize=(22,28))
ax3 = fig3.subplots()
yticks = []
for i in range(start,end+1):
    xticks.append(i)  
    x = fit_8_3(i)
    N_lengths = [x + y for x,y in zip(N_lengths,x)]
    y = [a for a in x if a!=0]
    if len(y) >= max_nos:
        #print(y)
        max_nos = len(y)
        high_lengths.append(i)
    n_4.append(x[2])
    n_6.append(x[4])
    ans = fit_8_3(i,1) 
    if i==18:
        print('hello')
    if ans[-1][1]%2==0 and len(ans)!=1:
        ans[-1][1] = ans[-1][1]//2
        ans.insert(0,ans[-1])
    elif ans[-1][1]%2!=0 and len(ans)==2 and ans[0][1]%2==0:
        ans[0][1] = ans[0][1]//2
        ans.append(ans[0])
    elif len(ans)%2!=0 and (len(ans)!=1): #total odd with odd last number
        ans.append(ans[0])
        del ans[0]
    elif len(ans)==1:
        ender=ans[0].copy()
        ender[1]=1
        ans.insert(0,ender)
        ans.append(ender)
        if ans[1][1]>2:
            ans[1][1]=ans[1][1]-2
        else:
            del ans[1]
    if len(ans)==2:
        dummy = ans[1] 
        ans[1]=ans[0]
        ans[0]=dummy
    prev_h = 0
    for j in range(len(ans)):
        if j==0:
            o = int(re.sub("'","",ans[j][0]))*ans[j][1]
            a = ax3.bar(i,o,align='center',width=0.8,color='green',edgecolor='k',)
            #prev_h = a[0].get_height()
            total=o
            yloc = o/2
        else:
            o = int(re.sub("'","",ans[j][0]))*ans[j][1]
            if j== len(ans)-1:
                a = ax3.bar(i,o,bottom=total,align='center',width=0.8,color='red',edgecolor='k',)
            else:
                a = ax3.bar(i,o,bottom=total,align='center',width=0.8,color='orange',edgecolor='k',)
            yloc = o/2+total
            total=o+total
        if j!= len(ans)-1:
            yticks.append(total)
        #print(j,yloc)
        width = int(a[0].get_width())
        xloc = a[0].get_x() +0.5*a[0].get_width()
        label = ax3.text(xloc, yloc,str(ans[j][0])+"x "+str(ans[j][1]), horizontalalignment='center',verticalalignment='center',size=25,\
                             clip_on=True,rotation=90)
        #plt.pause(0.05)
        #ax3.autoscale_view(True,True,True)
yticks=sorted(yticks)
ax3.set_xticks(xticks)
#ax3.set_yticks(yticks)    
ax3.yaxis.set_minor_locator(plt.MultipleLocator(1))
#ax3.grid(color='xkcd:black', which='major',linestyle='-',axis='y', linewidth=0.2)
ax3.tick_params(axis='both', which='major', labelsize=30,rotation=90)
name = "P:\\Presented_Material\\Config_"+str(start)+"_"+str(end)+".png"
fig3.savefig(name, bbox_inches='tight')