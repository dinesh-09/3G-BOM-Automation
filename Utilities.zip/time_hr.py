# -*- coding: utf-8 -*-
"""
Created on Tue Jun  5 09:16:02 2018

@author: Demon King
"""

def conv_tim_hr(input_time,str_op=0):
    if str_op==0:
        return(input_time//3600,input_time%3600//60,input_time%60)
    else:
        return(str(input_time//3600)+' hrs ',str(input_time%3600//60)+' mins ',\
               str(input_time%60)+' secs ')
        