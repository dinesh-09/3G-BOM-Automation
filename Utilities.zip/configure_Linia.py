# -*- coding: utf-8 -*-
"""
Created on Fri Jul 13 08:01:58 2018

@author: Demon King
"""

import sys
import re
from configure_8_3 import *
from express_as_sum import express_as_sum

def configure_Linia(length,Pend=0,ret_op=0):
    length_list = [n for n in [0]*7]
    if Pend==1 and length <=27:
        length_list = configure_8_3(length)
    else:
        if length<4:
            length_list = express_as_sum(list(range(2,9)),length)
        else:
            length_list[2:] = express_as_sum(list(range(4,9)),length)
    if ret_op == 0:
        return(length_list)
    else:
        length_dict = []
        dict_key = list(range(2,9))
        for i in range(len(dict_key)):
            if length_list[i]!=0:
                length_dict.append([str(dict_key[i])+"'",length_list[i]])
        if Pend!=0:        
            length_dict = re_config(length_dict)        
        else:        
            length_dict = re_config(length_dict,symm=0)        
        return(length_dict)
        
