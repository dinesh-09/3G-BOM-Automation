# -*- coding: utf-8 -*-
"""
Created on Wed Jul 18 08:44:57 2018

@author: Demon King
"""

def search_val(x,y,mult_flag=0):
    if mult_flag==0:
        try:
            return(x.index(y))
        except:
            return(None)
    else:
        if y in x:
            return([i for i,j in enumerate(x) if j==y])
        else:
            return(None)