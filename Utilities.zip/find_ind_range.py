# -*- coding: utf-8 -*-
"""
Created on Wed May 23 10:55:38 2018

@author: dbhatia
"""

def find_ind_range(target_list,number):
    if number not in target_list:
        return(-1,-2)
    else:
        return(target_list.index(number),len(target_list)-(target_list[::-1].index(number)+1))