# -*- coding: utf-8 -*-
"""
Created on Mon May 14 09:18:14 2018

@author: dbhatia
"""
import sys
def fit_345(num):
    multiples=[0,0,0]
    if num<3:
        print("Error! The number entered should be more than the value 3")
        sys.exit()
    
    if num%4 == 0: # Multiples of 4
        multiples[1] = num//4
        return(multiples)
        sys.exit()

    if num%4 <3:
        if ((num%4)+4)%5==0: # If 10
            multiples[2]=int((num%4+4)//5)
            multiples[1]=num//4-1
        else:
            multiples[2]=(num%4+8)/5
            multiples[1]=num//4-2
    else:
        multiples[1]=num//4
        multiples[0]=int((num%4)//3)

    return(multiples)
         