# -*- coding: utf-8 -*-
"""
Created on Fri May 11 13:30:59 2018

@author: Demon King
"""
import sys
def fit_8_2(number):
    length_list=[n for n in [0]*7]  
    if number <2:
        if number == 0:
            return(length_list)
        else:
            print("Length's less than 2' are not allowed")
    
    if number<=8:
        length_list[number-2] = 1
    elif number <=16:
        if number%2!=0:  
            if number == 9:
                length_list[2],length_list[3]=1,1
            elif number == 11:
                length_list[3],length_list[4]=1,1
            elif number == 13:
                length_list[4],length_list[5]=1,1
            elif number == 15:
                length_list[5],length_list[6]=1,1
        else:
            if number == 14:
                length_list[4],length_list[6]=1,1
            else:
                length_list[number//2-2] = 2
    else:
        #if number%8<16:
        if number%8==1:
            length_list[-1] = number//8-1
            number=number%8+8
        else:
            length_list[-1] = number//8
            number=number%8
        length_list_2 = fit_8_2(number)
        length_list = [x + y for x,y in zip(length_list,length_list_2)]
#        else:
#            if number%2==0:
#                length_list = fit_8_2(number/2)*2
#            else:
#                length_list[-1] = number//8
#                length_list[number%8-2] = 1
    return(length_list)




         
            
         