# -*- coding: utf-8 -*-
"""
Created on Fri May 11 13:30:59 2018

@author: dbhatia
"""
import sys


def express_as_sum(num_list,number):
    diff = [x-y for x,y in zip(sorted(num_list)[1:],sorted(num_list)[:-1])]
    diff=[abs(a) for a in diff]
    flag = 0
    if min(diff) != max(diff):
        print("Error, the numbers in the list are not consecutive")
        sys.exit()
    
    list_min = min(num_list)
    list_max = max(num_list)
    #print("Data type of number",type(number)) 
    #print("Data type of list_min",type(list_min)) 
    if number < list_min:
        print("Error! The minimum number in your list is less than the target number")
        sys.exit()
    
    if (list_max+1)//list_min != 2:
        flag=1
        
    diff = number
    check_num = list_max
    multiple_list=[]
    
    for i in range(len(num_list)-1,-1,-1):
        check_num=num_list[i]
        if diff%check_num <list_min and diff%check_num>0:
            multiple_list.append(diff//check_num-1)
            diff = diff%check_num+check_num
        else:
            multiple_list.append(diff//check_num)
            diff=diff%check_num
        
    #print('Iterations Complete')
    #if len(multiple_list)<len(num_list.shape[0]):
        #for m in range(len(multiple_list)-len(num_list)+1):
        #    multiple_list.append(0)
    return(multiple_list[::-1])

        
#target = int(input\
#    ("Enter the target number for expressing as a sum of consecutive numbers \n"))  
#num = input("Enter the consecutive numbers in one line separated by commas \n")
#num=[int(e.strip()) for e in num.split(',')]
# target = 255
# num=[4,5,3]
# #num= np.array(num)
# output=express_as_sum(num,target)
# print("The multiples are ",output[::-1])


         
            
         