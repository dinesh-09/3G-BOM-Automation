# -*- coding: utf-8 -*-
"""
Created on Thu Jul 19 13:05:26 2018

@author: Demon King
"""

import matplotlib.pyplot as plt
target = 20
ans = fit_8_2(target)
for a in range(2,9):
    if ans[a-2] !=0:
        print("Number of sections of length",a,"feet totalling to",target,"feet are",ans[a-2],)
m = 30
n_8 = []
N_lengths =  [n for n in [0]*7]  
lengths = [2,3,4,5,6,7,8]
rect_labels = []
fig1 = plt.figure(1,figsize=(12,10))
ax1 = fig1.subplots()
fig2 = plt.figure(2,figsize=(12,10))
ax2 = fig2.subplots()
for i in range(2,m+1):
    x = fit_8_2(i)
    N_lengths = [x + y for x,y in zip(N_lengths,x)]
    n_8.append(x[-1])
    
ax2.plot(list(range(2,m+1)),n_8,'r-*')

rects = ax1.bar(lengths,N_lengths,align='center',tick_label=lengths,width=0.4)
i=0
max_height = max([rect.get_height() for rect in rects])
for rect in rects:
    width = int(rect.get_width())
    yloc = rect.get_height()/2
    xloc = rect.get_x() +0.5*rect.get_width()
    label = ax1.text(xloc, yloc, N_lengths[i], horizontalalignment='center',verticalalignment='center', weight='bold',\
                         clip_on=True)
    i +=1
ax1.set_title("Total quantity of various sections used upto lengths of "+str(m)+" feet",fontsize=12)    
plt.show()